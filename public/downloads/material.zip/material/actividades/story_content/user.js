function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5cmNnv0H4Au":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

